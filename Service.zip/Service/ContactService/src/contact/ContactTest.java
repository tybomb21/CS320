package contact;

public class ContactTest {

}
