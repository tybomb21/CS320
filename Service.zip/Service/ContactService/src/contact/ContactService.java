package contact;
import java.util.ArrayList;


public class ContactService {
//Array to hold contacts

	private ArrayList<Contact> contacts;

		public ContactService()
		{
//call our Array
        contacts = new ArrayList<>();
		}

//Adding a contact
		public boolean addContact(Contact contact){
			boolean contactAlready= false;
//run through all the contacts in the list made
			for (Contact contactList:contacts)
			{
//Check for existing contact
				if (contactList.equals(contact))
				{
					contactAlready = true;
				}
			}
//if no contact found, add
			if (!contactAlready)
			{
				contacts.add(contact);
//return true after added
				return true;
			}
			else
			{
				return false;
			}
		}

//insert delete function
		public boolean deleteContact(String contactID)
		{
//search array
			for (Contact contactList:contacts)
			{
//if contact found, delete
				if (contactList.getContactID().equals(contactID))
				{
//return true after deleted
					contacts.remove(contactList);
					return true;
				}
			}
//else return false
			return false;
		}

//update method
		public boolean updateContact(String contactID, String firstName, String lastName, String phoneNumber, String address)
		{
//search array
			for (Contact contactList:contacts)
			{
//if found, make updates
				if (contactList.getContactID().equals(contactID))
				{
					if(!firstName.equals("") && !(firstName.length()>10))
					{
						contactList.setFirstName(firstName);
					}
					if(!lastName.equals("") && !(lastName.length()>10))
					{
						contactList.setFirstName(lastName);
					}
					if(!phoneNumber.equals("") && (phoneNumber.length()==10))
					{
						contactList.setFirstName(phoneNumber);
					}
					if(!address.equals("") && !(address.length()>30))
					{
						contactList.setFirstName(address);
					}
					return true;
				}
			}
//else return false
			return false;
		}
	}