package contact;
import org.junit.Test;
public class ContactServiceTest {

//testing, adding, deleting, and updating


@Test
public void testAdd()
{
ContactService cs = new ContactService();
Contact test1 = new Contact("00001", "Some", "Guy", "8005551111", "4 Privet Drive");
assertEquals(true, cs.addContact(test1));
}

private void assertEquals(boolean b, boolean addContact) {
	// TODO Auto-generated method stub
	
}

@Test
public void testDelete()
{
ContactService cs = new ContactService();

Contact test1 = new Contact("00001", "Some", "Guy", "8005551111", "4 Privet Drive");
Contact test2 = new Contact("00002", "Another", "Person", "8005552222", "521 B Baker Street");
Contact test3 = new Contact("00003", "Its", "Me", "8005553333", "3000 Penn Ave");

cs.addContact(test1);
cs.addContact(test2);
cs.addContact(test3);

assertEquals(true, cs.deleteContact("00001"));
assertEquals(false, cs.deleteContact("00002"));
assertEquals(false, cs.deleteContact("00001"));
}

@Test
public void testUpdate()
{
ContactService cs = new ContactService();

Contact test1 = new Contact("00001", "Some", "Guy", "8005551111", "4 Privet Drive");
Contact test2 = new Contact("00002", "Another", "Person", "8005552222", "521 B Baker Street");
Contact test3 = new Contact("00003", "Its", "Me", "8005553333", "3000 Penn Ave");

cs.addContact(test1);
cs.addContact(test2);
cs.addContact(test3);

assertEquals(true, cs.updateContact("00002", "Another", "Person", "8005552222", "521 B Baker Street"));
assertEquals(false, cs.updateContact("00007", "Another", "Person", "8005552222", "521 B Baker Street"));
}

}