/**
 * 
 */
/**
 * @author Tyler Morgan
 *
 */
module ContactService {
	requires org.junit.jupiter.api;
	requires junit;
}