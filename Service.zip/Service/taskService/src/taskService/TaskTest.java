package taskService;

import org.junit.Test;

public class TaskTest {

 @Test public void createValidTaskData() {
      Task task = new Task("00001", "Homework", "Working on coding Projects");
      System.out.println(task);
   }
   
}
