import java.util.Comparator;
import java.util.Date;

public class Appointment {

    // required variables
    final private byte APPOINTMENT_ID_LENGTH;
    final private byte APPOINTMENT_DESCRIPTION_LENGTH;
    final private String INITIALIZER;
    private String appointmentId;
    private Date appointmentDate;
    private String description;
	public Comparator<?> compareById;

    {
        APPOINTMENT_ID_LENGTH = 10;
        APPOINTMENT_DESCRIPTION_LENGTH = 50;
        INITIALIZER = "INITIAL";
    }

    // constructor
    Appointment() {
        Date today = new Date();
        appointmentId = INITIALIZER;
        appointmentDate = today;
        description = INITIALIZER;
    }

    // constructor
    Appointment(String id) {
        Date today = new Date();
        updateAppointmentID(id);
        appointmentDate = today;
        description = INITIALIZER;
    }

    // constructor
    Appointment(String id, Date date) {
        updateAppointmentID(id);
        updateDate(date);
        description = INITIALIZER;
    }

    // constructor
    Appointment(String id, Date date, String description) {
        updateAppointmentID(id);
        updateDate(date);
        updateDescription(description);
    }

    // getters
    public String getDescription() {
        return description;
    }

    public String getAppointmentId() { return
            appointmentId;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    // updateAppointmentID() function
    public void updateAppointmentID(String id) {
        
        if (id == null) {
            throw new IllegalArgumentException("Appointment ID cannot be null.");
        }
        // The appointment object shall have a required unique appointment ID string that
        // cannot be longer than 10 characters.
        else if (id.length() > APPOINTMENT_ID_LENGTH) {
            throw new IllegalArgumentException("Appointment ID cannot exceed " +
                    APPOINTMENT_ID_LENGTH +
                    " characters.");
        }
        else {
            this.appointmentId = id;
        }
    }

    // updateDate() function
    public void updateDate(Date date) {
        // Appointment date cannot be null
        if (date == null) {
            throw new IllegalArgumentException("Appointment date cannot be null.");
        }
        // check if the date is in the past.
        else if (date.before(new Date())) {
            throw new IllegalArgumentException("Cannot make appointment in the past.");
        }
        else {
            this.appointmentDate = date;
        }
    }

    // updateDescription() function
    public void updateDescription(String description) {
        // The description field shall not be null.
        if (description == null) {
            throw new IllegalArgumentException(
                    "Appointment description cannot be null.");
        }
        // The appointment object shall have a required description String field that cannot be longer than 50 characters
        else if (description.length() > APPOINTMENT_DESCRIPTION_LENGTH) {
            throw new IllegalArgumentException("Appointment description cannot exceed " + APPOINTMENT_DESCRIPTION_LENGTH + " characters.");
        }
        else {
            this.description = description;
        }
    }

	public String getId() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setName(String name) {
		// TODO Auto-generated method stub
		
	}
}
