import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class AppointmentService {


	private final static Appointment Appointment = null;
	public static List<Appointment> Appointments = new ArrayList<>();

	public void main(String[] args) {



		AppointmentService service = new AppointmentService();
		AppointmentService.addAppointment();
		AppointmentService.addAppointment();
		AppointmentService.addAppointment();


		for (Appointment obj : Appointments) {

			System.out.println(obj);

		}


		AppointmentService.addAppointment();
		System.out.println("Delete Appointment ID #00002");
		service.deleteAppointment();
		System.out.println("Update Appointment ID #00003");
		service.update(new Appointment());

		for (Appointment obj : Appointments) {

			System.out.println(obj);

		}

}


@Test
public static void addAppointment() {

int index = getIndex(Appointment);

//validate appointment ID

	if (index < 0 && validateID(Appointment.getId()) && validateName(Appointment.getName()) && validateDescription(Appointment.getDescription())) {

		Appointments.add(Appointment);

		return;

	}

		return;

	}

//delete appointment
@Test 

public void deleteAppointment() {

int index = getIndex(new Appointment());


	if (index >= 0)

		Appointments.remove(index);

	}

private static int getIndex(Appointment appointment) {
	// TODO Auto-generated method stub
	return 0;
}


//update appointment

public void update(Appointment Appointment) {

	for (Appointment obj : Appointments) {

		if (obj.equals(Appointment) && validateName(Appointment.getName()) && validateDescription(Appointment.getDescription())) {

			obj.setName(Appointment.getName());

			obj.updateDescription(Appointment.getDescription());

		}

	}

}


public static boolean validateID(String id) {

	if (id != null && id.length() <= 10)

		return true;

	return false;

}



public static boolean validateName(String name) {

	if (name != null && name.length() <= 20)

		return true;

	return false;

}



public static boolean validateDescription(String description) {

	if (description != null && description.length() <= 50)

		return true;

	return false;

	}

}