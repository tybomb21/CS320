import static org.junit.jupiter.api.Assertions.*;
import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AppointmentTest {

    private String id, description;
    private String tooLongId, tooLongDescription;
    private Date date, pastDate;

    @SuppressWarnings("deprecation")
    @BeforeEach
    void setUp() {
        id = "1234567890";
        description = "The appt object shall have a required description.";
        date = new Date(3021, Calendar.JANUARY, 1);
        tooLongId = "111222333444555666777888999";
        tooLongDescription = "This description is too long for the appointment requirements but good for testing.";
        pastDate = new Date(0);
    }

    @Test
    void testUpdateAppointmentID() {
        Appointment appointment = new Appointment();
        assertThrows(IllegalArgumentException.class,
                () -> appointment.updateAppointmentID(null));
        assertThrows(IllegalArgumentException.class,
                () -> appointment.updateAppointmentID(tooLongId));
        appointment.updateAppointmentID(id);
        assertEquals(id, appointment.getAppointmentId());
    }

    @Test
    void testGetAppointmentID() {
        Appointment appointment = new Appointment(id);
        assertNotNull(appointment.getAppointmentId());
        assertEquals(appointment.getAppointmentId().length(), 10);
        assertEquals(id, appointment.getAppointmentId());
    }

    @Test
    void testUpdateDate() {
        Appointment appointment = new Appointment();
        assertThrows(IllegalArgumentException.class, () -> appointment.updateDate(null));
        assertThrows(IllegalArgumentException.class, () -> appointment.updateDate(pastDate));
        appointment.updateDate(date);
        assertEquals(date, appointment.getAppointmentDate());
    }

    @Test
    void testGetAppointmentDate() {
        Appointment appointment = new Appointment(id, date);
        assertNotNull(appointment.getAppointmentDate());
        assertEquals(date, appointment.getAppointmentDate());
    }

    @Test
    void testUpdateDescription() {
        Appointment appointment = new Appointment();
        assertThrows(IllegalArgumentException.class, () -> appointment.updateDescription(null));
        assertThrows(IllegalArgumentException.class, () -> appointment.updateDescription(tooLongDescription));
        appointment.updateDescription(description);
        assertEquals(description, appointment.getDescription());
    }

    @Test
    void testGetDescription() {
        Appointment appointment = new Appointment(id, date, description);
        assertNotNull(appointment.getDescription());
        assertTrue(appointment.getDescription().length() <= 50);
        assertEquals(description, appointment.getDescription());
    }
}