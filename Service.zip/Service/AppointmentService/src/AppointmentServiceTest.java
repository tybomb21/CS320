import org.junit.Test;
import java.util.ArrayList;
import java.util.List;

public class AppointmentServiceTest {

public static List<Appointment> Appointments = new ArrayList<>();

@Test public void validAppointmentData() {

Appointment Appointment = new Appointment();

	addAppointment(Appointment);

	System.out.println("New Appointment: " + Appointments);

	System.out.println("size: " + Appointments.size());

}

@Test public void invalidID() {

Appointment Appointment = new Appointment();

	addAppointment(Appointment);

	System.out.println("size: " + Appointments.size());

}

@Test public void invalidName() {

Appointment Appointment = new Appointment();

	addAppointment(Appointment);

	System.out.println("size: " + Appointments.size());

}

@Test public void invalidDescription() {

Appointment Appointment = new Appointment();

	addAppointment(Appointment);

	System.out.println("size: " + Appointments.size());

}

@Test public void existingID() {

Appointment Appointment = new Appointment();

	addAppointment(Appointment);

	System.out.println("size: " + Appointments.size());

}

@Test public void updateAppointment() {

Appointment Appointment = new Appointment();

	update(Appointment);

	System.out.println("Updated: " + Appointments);

	System.out.println("size: " + Appointments.size());

}

@Test 
public void deleteAppointment() {

deleteAppointment("#00001");

	System.out.println("size: " + Appointments.size());

}

public void addAppointment(Appointment Appointment) {

//search for appointment ID
int index = getIndex(Appointment);

	if (index < 0 && validateID(Appointment.getId()) && validateName(Appointment.getName()) && validateDescription(Appointment.getDescription())) {

		Appointments.add(Appointment);

		return;

	}

		return;

	}



//delete appointment
@Test 

public void deleteAppointment(String id) {

int index = getIndex(new Appointment());


	if (index >= 0)

		Appointments.remove(index);

	}

private int getIndex(Appointment appointment) {
	// TODO Auto-generated method stub
	return 0;
}


public void update(Appointment Appointment) {

	for (Appointment obj : Appointments) {

		if (obj.equals(Appointment) && validateName(Appointment.getName()) && validateDescription(Appointment.getDescription())) {

			obj.setName(Appointment.getName());

			obj.updateDescription(Appointment.getDescription());

		}

	}

}



public boolean validateID(String id) {

	if (id != null && id.length() <= 10) {

		return true;
	}

		return false;

	}



public boolean validateName(String name) {

	if (name != null && name.length() <= 20) {

		return true;
	}
	
		return false;

	}



public boolean validateDescription(String description) {

	if (description != null && description.length() <= 50) {

		return true;
	
	}

		return false;

	}

}